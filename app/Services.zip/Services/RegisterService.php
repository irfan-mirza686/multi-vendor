<?php
namespace App\Services;

use Illuminate\Support\Facades\Http;
use Session;
use App\Models\{
	R,
};
use Auth;

class RegisterService
{

}