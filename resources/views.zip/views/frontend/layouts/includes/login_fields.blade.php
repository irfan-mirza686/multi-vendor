<div class="form-group">
    <input type="email" name="email" class="form-control auth-form-input" placeholder="Email Address" maxlength="255"
        required>
</div>
<div class="form-group">
    <input type="password" name="password" class="form-control auth-form-input" placeholder="Password" minlength="4"
        maxlength="255" autocomplete="on" required>
</div>
<div class="form-group text-right">
    <a href="javascript:void(0);" class="link-forgot-password">Forgot
        Password?</a>
</div>
<div class="form-group">
    <button type="submit" class="btn btn-md btn-dark btn-custom btn-block">Login</button>
</div>
