<label for="countries" class="form-label">Countries</label>
<select class="form-select form-select-sm mb-3 appendCountries" id="appendCountries" name="country_id" aria-label=".form-select-sm example">
    <option selected="" value="">-select-</option>
</select>