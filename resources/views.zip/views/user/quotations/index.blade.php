@extends('frontend.layouts.layout')
@section('content')

<div id="menu-overlay"></div><!-- Wrapper -->
    <div id="wrapper">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <nav class="nav-breadcrumb" aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0);">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Quote Requests</li>
                        </ol>
                    </nav>

                    <h1 class="page-title">Quote Requests</h1>
                </div>
            </div>

            <div class="row">
                <div class="col-sm-12">
                    <div class="row-custom">
                        <div class="profile-tab-content">
                            <!-- include message block -->

                            <!--print error messages-->

                            <!--print custom error message-->
                            <div class="table-responsive">
                                <table class="table table-quote_requests table-striped">
                                    <thead>
                                        <tr>
                                            <th scope="col">Quote</th>
                                            <th scope="col">Product</th>
                                            <th scope="col">Seller</th>
                                            <th scope="col">Status</th>
                                            <th scope="col">Seller's Bid</th>
                                            <th scope="col">Updated</th>
                                            <th scope="col">Options</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    </tbody>
                                </table>
                            </div>
                            <p class="text-center">
                                No records found! </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="table-pagination">
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection

@section('custom-js')
<script src="{{asset('assets/vendor_assets/profile/products.js')}}"></script>

@endsection
